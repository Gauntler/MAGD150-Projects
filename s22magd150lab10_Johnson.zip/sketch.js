var dirx, diry, dirz, img1;
let cam;
let delta = 0.01;
function preload(){
    img1 = loadImage('map.jpg');
}


function setup() {
  createCanvas(800, 400, WEBGL);
  dirx = random(-.5, .5); 
  diry = random(-.5, .5);
  dirz = random(-.5, .5);

  cam = createCamera();
  // set initial pan angle
  cam.pan(-0.8);
}

function draw() {
  background(0);
  
  cam.pan(delta);

  if (frameCount % 150 === 0) {
    delta *= -1;
  }

  let locX = mouseX - height / 2;
  let locY = mouseY - width / 2;

  ambientLight(50);
  directionalLight(255, 255, 255, dirx, diry, dirz);
  pointLight(255, 255, 255, locX, locY, 250);

  push();
  translate(-width / 3, 0, 0);
  rotateZ(frameCount * 0.02);
  texture(img1);
//  specularMaterial(250);
  box(100, 100, 100);
  pop();
  
  
  push();
  translate(-width / -3, 0, 0);
  rotateX(frameCount * 0.02);
  texture(img1);
  //specularMaterial(250);
  box(100, 100, 100);
  pop();
  
  
  push();
  translate(-width / 100, 40, 70);
  rotateZ(frameCount * 0.02);
  rotateX(frameCount * 0.02);
  texture(img1);
  //specularMaterial(250);
  box(100, 100, 100);
  pop();
  
  

}