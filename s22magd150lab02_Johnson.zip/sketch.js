function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
  colorMode(RGB, 100);
  let a = color(0,0,70);
  fill(a);
  ellipse(200,200,130,130);
  colorMode(HSB);
  let b = color(100,50,50);
  let c = color(37,17,66);
  fill(b);
  ellipse(200,200,270,20);
  ellipse(57,50,20,20);
  fill(c);
  arc(350, 50, 80, 80, 0, PI + QUARTER_PI, PIE);
  colorMode(HSL);
  let d = color(55,57,80);
  let f = color (57,8,40);
  let g = color (360,68,28);
  fill(d);
beginShape(TRIANGLE_FAN);
vertex(60, 60);
vertex(60, 15);
vertex(102, 50);
vertex(60, 85);
vertex(32, 60);
vertex(60, 20);
endShape();
  beginShape(TRIANGLE_FAN);
vertex(355, 350);
vertex(355, 325);
vertex(390, 350);
vertex(355, 390);
vertex(320, 350);
vertex(355, 325);
endShape();
  ellipse(50,130,20,20);
  ellipse(100,280,20,20);
  ellipse(300,130,20,20);
  ellipse(200,60,20,20);
  fill(f);
  triangle(50, 380, 50, 300, 150, 340);
  triangle(50, 390, 50, 380, 180, 340);
  triangle(50, 380, 50, 320, 200, 340);
  fill(g);
  triangle(50, 380, 50, 320, 200, 340);
  
}