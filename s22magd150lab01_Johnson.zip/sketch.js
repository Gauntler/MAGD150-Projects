function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  rectMode(CORNER);
  strokeWeight(5);
  fill(70);
  rect(0, 200, 150, 200);
  rect(150, 140, 100, 310);
  rect(250, 200, 200, 200);
  
  fill(255)
  rect(20, 220, 30, 40);
  fill(255)
  rect(60, 220, 30, 40);
  fill(255)
  rect(100, 220, 30, 40);
  fill(255)
  rect(270, 220, 30, 40);
  fill(255)
  rect(310, 220, 30, 40);
  fill(255)
  rect(350, 220, 30, 40);
  fill(255)
  rect(20, 280, 30, 40);
  fill(255)
  rect(60, 280, 30, 40);
  fill(255)
  rect(100, 280, 30, 40);
  fill(255)
  rect(270, 280, 30, 40);
  fill(255)
  rect(310, 280, 30, 40);
  fill(255)
  rect(350, 280, 30, 40);
  fill(255)
  rect(60, 340, 30, 40);
  fill(255)
  rect(20, 340, 30, 40);
  fill(255)
  rect(100, 340, 30, 40);
  fill(255)
  rect(270, 340, 30, 40);
  fill(255)
  rect(310, 340, 30, 40);
  fill(255)
  rect(350, 340, 30, 40);
  
  rectMode(RADIUS);
  fill(255)
  rect(177, 365, 20, 15);
  fill(255)
  rect(223, 365, 20, 15);
  fill(255)
  rect(177, 315, 20, 15);
  fill(255)
  rect(177, 265, 20, 15);
  fill(255)
  rect(177, 215, 20, 15);
  fill(255)
  rect(177, 165, 20, 15);
  fill(255)
  rect(223, 315, 20, 15);
  fill(255)
  rect(223, 265, 20, 15);
  fill(255)
  rect(223, 215, 20, 15);
  fill(255)
  rect(223, 165, 20, 15);
  ellipse(350,40,50,50);
  
}  
