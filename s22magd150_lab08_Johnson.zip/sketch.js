//First I set the variables that will be used later in the project
var f,f2, img1, pdf;
let list = [];
let index =0;

function preload(){
//Then I use the preload function to assign meaning to variables making sure I have all of my required assets for the project ready
  
  f = loadFont("arial.ttf");
  f2 = loadFont("impact.ttf");
  img1= loadImage("Beach.jpg");
  list = loadStrings("test.txt");
  img2 = loadImage("Shark2.jpg");
}

function setup() {
  createCanvas(480, 300);
  pdf = createPDF();
  pdf.beginRecord();
}
//I then place the images adjusting their size when necessary
function draw() {
  background(225);
image(img1, 0, 0, width, height);
image(img2,150,0,width/2, height/2)
  textFont(f);
  fill(255);
//Then I write lines of text making sure to adjust its location on the poster with RIGHT, LEFT, and CENTER
  textAlign(RIGHT);
  text("COMING THIS FALL", width/2, 160);
  textAlign(LEFT);
  textFont(f);
  text("A STORY UNLIKE ANY OTHER", width/2, 200);
  textAlign(CENTER);
   textFont(f2);
  text("FLYING SHARK.", width/2, 240);
  
  text(list[index], width/2, height-30);
  
}
//finally I make something interactable with a string of stext that reacts with mouse clicks.
function mousePressed(){
  index = (index+1)%list.length;
}

function keyPressed(){
  pdf.save();
}